<?php
/**
 * Plugin Name:       M.H - WooCommerce Payments
 * Plugin URI:        https://example.com/
 * Description:       Creates payment forms that integrate with WooCommerce and the main M.H CRM.
 * Version:           1.0.0
 * Author:            Your Name
 * Requires at least: 5.0
 * Requires PHP:      7.2
 * Depends:           M.H - מערכת CRM מאוחדת (עצמאית), WooCommerce
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MH_WC_PAYMENTS_DIR', plugin_dir_path( __FILE__ ) );
define( 'MH_WC_PAYMENTS_URL', plugin_dir_url( __FILE__ ) );
define( 'MH_WC_PAYMENTS_VERSION', '1.0.0' );

function mh_wc_payments_run() {
    // Check for dependencies: Main M.H Plugin and WooCommerce
    if ( ! class_exists( 'M_H_Plugin' ) || ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', 'mh_wc_payments_missing_deps_notice' );
        return;
    }

    require_once MH_WC_PAYMENTS_DIR . 'includes/class-mh-wc-payments-core.php';
    new MH_WC_Payments_Core();
}
add_action( 'plugins_loaded', 'mh_wc_payments_run', 20 ); // Run with a later priority

function mh_wc_payments_missing_deps_notice() {
    $missing = [];
    if (!class_exists('M_H_Plugin')) {
        $missing[] = '"M.H - מערכת CRM מאוחדת (עצמאית)"';
    }
    if (!class_exists('WooCommerce')) {
        $missing[] = '"WooCommerce"';
    }
    ?>
    <div class="error">
        <p>The <strong>M.H - WooCommerce Payments</strong> add-on requires the following plugins to be active: <?php echo implode(' and ', $missing); ?>.</p>
    </div>
    <?php
}