<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Core class for the M.H WooCommerce Payments Add-on.
 * Version: 1.3.2 - Fixed and optimized metabox JavaScript for interactive placeholders and image uploaders.
 */
class MH_WC_Payments_Core {

    public function __construct() {
        add_action( 'init', [ $this, 'register_payment_form_post_type' ] );
        add_action( 'add_meta_boxes', [ $this, 'add_meta_boxes' ] );
        add_action( 'save_post_mh_payment_form', [ $this, 'save_meta_data' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ] );
        add_action( 'wp_ajax_mh_handle_wc_form', [ $this, 'handle_form_submission' ] );
        add_action( 'wp_ajax_nopriv_mh_handle_wc_form', [ $this, 'handle_form_submission' ] );
        add_shortcode( 'mh_wc_payment_form', [ $this, 'render_shortcode' ] );
        
        // WooCommerce Hooks
        add_action( 'woocommerce_checkout_create_order_line_item', [ $this, 'add_data_to_order_item' ], 10, 4 );
        add_action( 'woocommerce_order_status_changed', [ $this, 'handle_payment_status_change' ], 10, 4 );
    }
    
    public function enqueue_admin_scripts($hook) {
        global $post;
        if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
            if ( isset($post->post_type) && 'mh_payment_form' === $post->post_type ) {
                wp_enqueue_media();
            }
        }
    }

    public function register_payment_form_post_type() {
        register_post_type( 'mh_payment_form', [
            'labels' => ['name' => 'Payment Forms', 'singular_name' => 'Payment Form'],
            'public' => false, 'show_ui' => true, 'show_in_menu' => true,
            'menu_position' => 26, 'menu_icon' => 'dashicons-cart', 'supports' => [ 'title' ],
        ]);
    }

    public function add_meta_boxes() {
        add_meta_box('mh_wc_form_builder', 'Payment Form Builder', [ $this, 'render_meta_box' ], 'mh_payment_form', 'normal', 'high');
        add_meta_box('mh_wc_form_shortcode', 'Shortcode', [ $this, 'render_shortcode_metabox' ], 'mh_payment_form', 'side', 'default');
    }

    public function render_meta_box( $post ) {
        wp_nonce_field( 'mh_wc_save_meta_data', 'mh_wc_nonce' );
        $form_fields = get_post_meta( $post->ID, '_mh_form_fields', true ) ?: [];
        $save_to_crm = get_post_meta( $post->ID, '_mh_save_to_crm', true );
        $crm_owner_id = get_post_meta( $post->ID, '_mh_crm_owner_id', true ) ?: 1;
        $wc_product_name = get_post_meta( $post->ID, '_mh_wc_product_name', true );
        $wc_product_image_id = get_post_meta( $post->ID, '_mh_wc_product_image_id', true );
        $wc_pending_message = get_post_meta( $post->ID, '_mh_wc_pending_message', true );
        $wc_pending_image_id = get_post_meta( $post->ID, '_mh_wc_pending_image_id', true );
        $wc_success_message = get_post_meta( $post->ID, '_mh_wc_success_message', true );
        $wc_success_image_id = get_post_meta( $post->ID, '_mh_wc_success_image_id', true );
        $wc_failed_message = get_post_meta( $post->ID, '_mh_wc_failed_message', true );
        $wc_failed_image_id = get_post_meta( $post->ID, '_mh_wc_failed_image_id', true );
        $crm_db_fields = ['' => '-- ללא מיפוי --', 'conta_name' => 'שם', 'f_m' => 'שם משפחה', 'conta_phone' => 'טלפון', 'gender' => 'מגדר', 'tg1' => 'תג 1 (סטטוס)', 'tg2' => 'תג 2', 'tg3' => 'תג 3'];
        $crm_db_fields['payment_amount'] = 'סכום לתשלום (WooCommerce)';
        ?>
        <style>
            .mh-form-builder-container { padding: 10px; }
            .mh-form-section { border: 1px solid #ccd0d4; padding: 15px; margin-bottom: 20px; border-radius: 4px; background: #fff; }
            #mh-fields-wrapper .mh-field-row { display: grid; grid-template-columns: 2fr 1fr 1fr 1.5fr auto; gap: 10px; align-items: center; background: #f9f9f9; padding: 10px; border-radius: 4px; margin-bottom: 10px; }
            .mh-placeholders-list { background: #f0f6fc; border: 1px dashed #a5c8e8; padding: 10px; border-radius: 4px; margin-top: 10px; }
            .mh-placeholders-list .placeholder-btn { cursor: pointer; background: #e1ecf7; padding: 2px 8px; border-radius: 4px; margin: 2px; display: inline-block; border: 1px solid #c3d9ec; font-family: monospace; }
            .mh-placeholders-list .placeholder-btn:hover { background: #d1e4f7; border-color: #a5c8e8;}
            .mh-image-preview { max-width: 100px; height: auto; border: 1px solid #ddd; padding: 5px; margin: 10px 0; display: none; }
        </style>
        <div class="mh-form-builder-container">
            <div class="mh-form-section">
                <h3>שדות הטופס</h3>
                <div id="mh-fields-wrapper">
                    <?php foreach ( $form_fields as $index => $field ) { $this->render_field_row($index, $field, $crm_db_fields); } ?>
                </div>
                <button type="button" id="mh-add-field-btn" class="button">הוסף שדה</button>
            </div>
            <div class="mh-form-section">
                <h3>הגדרות תשלום ו-CRM</h3>
                <p><label><strong>שם המוצר לחיוב:</strong><br><input type="text" name="mh_wc_product_name" value="<?php echo esc_attr($wc_product_name); ?>" class="regular-text" /></label></p>
                <p>
                    <label><strong>תמונת מוצר (תוצג בראש הטופס):</strong></label><br>
                    <?php $this->render_image_uploader('mh_wc_product_image_id', $wc_product_image_id); ?>
                </p>
                <hr>
                <h4>שמירת נתונים ל-CRM</h4>
                <p><label><input type="checkbox" name="mh_save_to_crm" value="1" <?php checked( $save_to_crm, '1' ); ?> /> <strong>הוסף/עדכן איש קשר ב-CRM של M.H</strong></label></p>
                 <p>
                    <label><strong>שמור אנשי קשר תחת המשתמש:</strong></label><br>
                    <select name="mh_crm_owner_id">
                        <?php
                        $users = get_users(['role__in' => ['administrator', 'editor', 'author']]);
                        foreach ($users as $user) {
                            echo '<option value="' . esc_attr($user->ID) . '" ' . selected($crm_owner_id, $user->ID, false) . '>' . esc_html($user->display_name) . '</option>';
                        }
                        ?>
                    </select>
                </p>
            </div>
            <div class="mh-form-section">
                <h3>הודעות וואטסאפ אוטומטיות</h3>
                <p><label><strong>הודעה בעת יצירת הזמנה (ממתין לתשלום):</strong><br><textarea name="mh_wc_pending_message" class="mh-message-textarea" rows="5" style="width: 100%;"><?php echo esc_textarea($wc_pending_message); ?></textarea></label></p>
                <p><label><strong>צרף תמונה להודעה:</strong></label><br><?php $this->render_image_uploader('mh_wc_pending_image_id', $wc_pending_image_id); ?></p>
                <div class="mh-placeholders-list"><strong>פלייסהולדרים זמינים:</strong> <span class="mh-placeholders-output"></span></div>
                <hr>
                <p><label><strong>הודעה לאחר תשלום מוצלח:</strong><br><textarea name="mh_wc_success_message" class="mh-message-textarea" rows="5" style="width: 100%;"><?php echo esc_textarea($wc_success_message); ?></textarea></label></p>
                <p><label><strong>צרף תמונה להודעה:</strong></label><br><?php $this->render_image_uploader('mh_wc_success_image_id', $wc_success_image_id); ?></p>
                <div class="mh-placeholders-list"><strong>פלייסהולדרים זמינים:</strong> <span class="mh-placeholders-output"></span> <button type="button" class="placeholder-btn" data-placeholder="{link_kabala}">{link_kabala}</button></div>
                <hr>
                <p><label><strong>הודעה לאחר תשלום שנכשל / בוטל:</strong><br><textarea name="mh_wc_failed_message" class="mh-message-textarea" rows="5" style="width: 100%;"><?php echo esc_textarea($wc_failed_message); ?></textarea></label></p>
                <p><label><strong>צרף תמונה להודעה:</strong></label><br><?php $this->render_image_uploader('mh_wc_failed_image_id', $wc_failed_image_id); ?></p>
                <div class="mh-placeholders-list"><strong>פלייסהולדרים זמינים:</strong> <span class="mh-placeholders-output"></span></div>
            </div>
        </div>
        <script>
            jQuery(document).ready(function($) {
                const wrapper = $('#mh-fields-wrapper');
                let fieldIndex = wrapper.find('.mh-field-row').length;
                const crmFields = <?php echo json_encode($crm_db_fields); ?>;
                
                // Generic Image Uploader
                $(document).on('click', '.mh-upload-image-btn', function(e) {
                    e.preventDefault();
                    const button = $(this);
                    const frame = wp.media({ title: 'בחר תמונה', button: { text: 'בחר תמונה' }, multiple: false });
                    frame.on('select', function() {
                        const attachment = frame.state().get('selection').first().toJSON();
                        button.siblings('.mh-image-id-input').val(attachment.id);
                        button.siblings('.mh-image-preview').attr('src', attachment.url).show();
                        button.siblings('.mh-remove-image-btn').show();
                    });
                    frame.open();
                });
                $(document).on('click', '.mh-remove-image-btn', function(e) {
                    e.preventDefault();
                    const button = $(this);
                    button.siblings('.mh-image-id-input').val('');
                    button.siblings('.mh-image-preview').attr('src', '').hide();
                    button.hide();
                });

                function updateAllPlaceholders() {
                    const labels = Array.from(wrapper.find('input[name*="[label]"]')).map(i => $(i).val()).filter(Boolean);
                    $('.mh-placeholders-output').each(function() {
                        $(this).html(labels.map(label => `<button type="button" class="placeholder-btn" data-placeholder="{${label}}">{${label}}</button>`).join(' '));
                    });
                }
                function toggleFieldOptions(selectElement) {
                    const row = $(selectElement).closest('.mh-field-row');
                    const requiredWrapper = row.find('.mh-field-required-wrapper');
                    const defaultValueWrapper = row.find('.mh-field-default-value-wrapper');
                    const isHiddenType = ['hidden', 'fixed_amount'].includes($(selectElement).val());
                    requiredWrapper.toggle(!isHiddenType);
                    defaultValueWrapper.toggle(isHiddenType);
                }
                $('#mh-add-field-btn').on('click', function() {
                    let mapOptions = Object.entries(crmFields).map(([k, v]) => `<option value="${k}">${v}</option>`).join('');
                    let typeOptions = `<option value="text">טקסט</option><option value="tel">טלפון</option><option value="email">אימייל</option><option value="textarea">אזור טקסט</option><option value="hidden">שדה מוסתר</option><option value="number">מספר (סכום)</option><option value="fixed_amount">סכום קבוע</option>`;
                    const newRowHTML = `<div class="mh-field-row"><input type="text" name="mh_form_fields[${fieldIndex}][label]" required /><select class="mh-field-type-select" name="mh_form_fields[${fieldIndex}][type]">${typeOptions}</select><select name="mh_form_fields[${fieldIndex}][map_to]">${mapOptions}</select><div class="mh-field-options"><label class="mh-field-required-wrapper"><input type="checkbox" name="mh_form_fields[${fieldIndex}][required]" value="1" /> שדה חובה</label><input type="text" class="mh-field-default-value-wrapper" name="mh_form_fields[${fieldIndex}][default_value]" placeholder="ערך ברירת מחדל" style="display:none;" /></div><a href="#" class="mh-remove-field-btn">הסר</a></div>`;
                    wrapper.append(newRowHTML);
                    fieldIndex++;
                    updateAllPlaceholders();
                });
                wrapper.on('click', '.mh-remove-field-btn', function(e) { e.preventDefault(); $(this).closest('.mh-field-row').remove(); updateAllPlaceholders(); });
                wrapper.on('change', '.mh-field-type-select', function() { toggleFieldOptions(this); });
                wrapper.on('input', 'input[name*="[label]"]', updateAllPlaceholders);
                
                $(document.body).on('click', '.placeholder-btn', function() {
                    const placeholder = $(this).data('placeholder');
                    const textarea = $(this).closest('.mh-placeholders-list').siblings('textarea, input[type="text"]').get(0);
                    if (textarea) {
                        const start = textarea.selectionStart;
                        const end = textarea.selectionEnd;
                        const text = $(textarea).val();
                        $(textarea).val(text.substring(0, start) + placeholder + text.substring(end));
                        textarea.focus();
                        textarea.selectionStart = textarea.selectionEnd = start + placeholder.length;
                    }
                });

                updateAllPlaceholders();
                wrapper.find('.mh-field-type-select').each(function() { toggleFieldOptions(this); });
            });
        </script>
        <?php
    }

    private function render_image_uploader($name, $value) {
        $image_url = $value ? wp_get_attachment_image_url($value, 'thumbnail') : '';
        ?>
        <div>
            <img class="mh-image-preview" src="<?php echo esc_url($image_url); ?>" style="<?php echo $value ? 'display:block;' : ''; ?>" />
            <input type="hidden" class="mh-image-id-input" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value); ?>" />
            <button type="button" class="button mh-upload-image-btn">העלה/בחר תמונה</button>
            <button type="button" class="button button-link-delete mh-remove-image-btn" style="<?php echo $value ? '' : 'display:none;'; ?>">הסר תמונה</button>
        </div>
        <?php
    }

    private function render_field_row($index, $field, $crm_db_fields) {
        $field_type = $field['type'] ?? 'text';
        $is_hidden_type = in_array($field_type, ['hidden', 'fixed_amount']);
        ?>
        <div class="mh-field-row">
            <input type="text" name="mh_form_fields[<?php echo $index; ?>][label]" value="<?php echo esc_attr( $field['label'] ?? '' ); ?>" required />
            <select class="mh-field-type-select" name="mh_form_fields[<?php echo $index; ?>][type]">
                <option value="text" <?php selected( $field_type, 'text' ); ?>>טקסט</option>
                <option value="tel" <?php selected( $field_type, 'tel' ); ?>>טלפון</option>
                <option value="email" <?php selected( $field_type, 'email' ); ?>>אימייל</option>
                <option value="textarea" <?php selected( $field_type, 'textarea' ); ?>>אזור טקסט</option>
                <option value="hidden" <?php selected( $field_type, 'hidden' ); ?>>שדה מוסתר</option>
                <option value="number" <?php selected( $field_type, 'number' ); ?>>מספר (סכום)</option>
                <option value="fixed_amount" <?php selected( $field_type, 'fixed_amount' ); ?>>סכום קבוע</option>
            </select>
            <select name="mh_form_fields[<?php echo $index; ?>][map_to]">
                <?php foreach($crm_db_fields as $key => $label): ?>
                    <option value="<?php echo esc_attr($key); ?>" <?php selected( $field['map_to'] ?? '', $key ); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
            <div class="mh-field-options">
                <label class="mh-field-required-wrapper" style="<?php echo $is_hidden_type ? 'display:none;' : ''; ?>"><input type="checkbox" name="mh_form_fields[<?php echo $index; ?>][required]" value="1" <?php checked( ! empty( $field['required'] ) ); ?> /> שדה חובה</label>
                <input type="text" class="mh-field-default-value-wrapper" name="mh_form_fields[<?php echo $index; ?>][default_value]" value="<?php echo esc_attr( $field['default_value'] ?? '' ); ?>" placeholder="ערך ברירת מחדל" style="<?php echo !$is_hidden_type ? 'display:none;' : ''; ?>" />
            </div>
            <a href="#" class="mh-remove-field-btn">הסר</a>
        </div>
        <?php
    }

    public function render_shortcode_metabox( $post ) {
        if ( $post->post_status === 'publish' ) {
            $shortcode = sprintf( '[mh_wc_payment_form id="%d"]', $post->ID );
            echo '<input type="text" value="' . esc_attr( $shortcode ) . '" readonly onfocus="this.select();" style="width:100%;">';
        } else {
            echo '<p>פרסם את הטופס כדי לקבל שורטקוד.</p>';
        }
    }

    public function save_meta_data( $post_id ) {
        if ( ! isset( $_POST['mh_wc_nonce'] ) || ! wp_verify_nonce( $_POST['mh_wc_nonce'], 'mh_wc_save_meta_data' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( isset( $_POST['mh_form_fields'] ) && is_array( $_POST['mh_form_fields'] ) ) {
            $sanitized_fields = [];
            foreach ( $_POST['mh_form_fields'] as $field ) {
                if ( ! empty( $field['label'] ) ) {
                    $sanitized_fields[] = ['label' => sanitize_text_field( $field['label'] ), 'type' => sanitize_key( $field['type'] ), 'required' => isset( $field['required'] ), 'map_to' => sanitize_key( $field['map_to'] ?? '' ), 'default_value' => sanitize_text_field( $field['default_value'] ?? '' )];
                }
            }
            update_post_meta( $post_id, '_mh_form_fields', $sanitized_fields );
        }
        update_post_meta( $post_id, '_mh_save_to_crm', isset( $_POST['mh_save_to_crm'] ) ? '1' : '0' );
        update_post_meta( $post_id, '_mh_crm_owner_id', intval( $_POST['mh_crm_owner_id'] ?? 1 ) );
        update_post_meta( $post_id, '_mh_wc_product_name', sanitize_text_field( $_POST['mh_wc_product_name'] ?? '' ) );
        update_post_meta( $post_id, '_mh_wc_product_image_id', sanitize_text_field( $_POST['mh_wc_product_image_id'] ?? '' ) );
        update_post_meta( $post_id, '_mh_wc_pending_message', sanitize_textarea_field( $_POST['mh_wc_pending_message'] ?? '' ) );
        update_post_meta( $post_id, '_mh_wc_pending_image_id', sanitize_text_field( $_POST['mh_wc_pending_image_id'] ?? '' ) );
        update_post_meta( $post_id, '_mh_wc_success_message', sanitize_textarea_field( $_POST['mh_wc_success_message'] ?? '' ) );
        update_post_meta( $post_id, '_mh_wc_success_image_id', sanitize_text_field( $_POST['mh_wc_success_image_id'] ?? '' ) );
        update_post_meta( $post_id, '_mh_wc_failed_message', sanitize_textarea_field( $_POST['mh_wc_failed_message'] ?? '' ) );
        update_post_meta( $post_id, '_mh_wc_failed_image_id', sanitize_text_field( $_POST['mh_wc_failed_image_id'] ?? '' ) );
    }
    
    public function enqueue_frontend_scripts() {
        wp_register_script( 'mh-wc-form-frontend-js', MH_WC_PAYMENTS_URL . 'assets/js/mh-wc-form-frontend.js', [ 'jquery' ], MH_WC_PAYMENTS_VERSION, true );
    }

    public function render_shortcode( $atts ) {
        $form_id = intval( $atts['id'] ?? 0 );
        if ( ! $form_id || get_post_type( $form_id ) !== 'mh_payment_form' ) return '<!-- MH WC Form: Invalid ID -->';
        wp_enqueue_script( 'mh-wc-form-frontend-js' );
        wp_localize_script( 'mh-wc-form-frontend-js', 'mhWcFormData', ['ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'mh_wc_form_submit_nonce' )] );
        $fields = get_post_meta( $form_id, '_mh_form_fields', true );
        if ( ! is_array( $fields ) ) return '<!-- MH WC Form: No fields -->';
        $product_image_id = get_post_meta( $form_id, '_mh_wc_product_image_id', true );
        $product_image_url = $product_image_id ? wp_get_attachment_image_url( $product_image_id, 'large' ) : '';
        ob_start();
        ?>
        <style>
            .mh-form-card { max-width: 500px; margin: 40px auto; background: #fff; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; opacity: 0; transform: translateY(20px); animation: fadeIn 0.8s ease-out forwards; }
            @keyframes fadeIn { to { opacity: 1; transform: translateY(0); } }
            .mh-form-header img { width: 100%; height: 200px; object-fit: cover; }
            .mh-form-wrapper { padding: 30px; }
            .mh-form-field { margin-bottom: 20px; }
            .mh-form-field label { display: block; font-weight: 600; margin-bottom: 8px; color: #333; }
            .mh-form-field input, .mh-form-field textarea { width: 100%; padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; transition: border-color 0.3s, box-shadow 0.3s; }
            .mh-form-field input:focus, .mh-form-field textarea:focus { border-color: #25D366; box-shadow: 0 0 0 3px rgba(37, 211, 102, 0.2); outline: none; }
            .mh-form-field input[readonly] { background:#f5f5f5; cursor: not-allowed; }
            .mh-form-submit-btn { display: block; width: 100%; background-color: #25D366; color: white; padding: 15px; border: none; border-radius: 8px; cursor: pointer; font-size: 18px; font-weight: bold; transition: all 0.3s; }
            .mh-form-submit-btn:hover { background-color: #128C7E; transform: translateY(-2px); box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
            .mh-form-response { margin-top: 15px; padding: 12px; border-radius: 8px; display: none; }
            .mh-form-response.success { background: #eaf7ec; border: 1px solid #a4d4ad; color: #1e4620; }
            .mh-form-response.error { background: #fdecea; border: 1px solid #f7b0a8; color: #5b1e18; }
        </style>
        <div class="mh-form-card">
            <?php if ($product_image_url): ?>
            <div class="mh-form-header">
                <img src="<?php echo esc_url($product_image_url); ?>" alt="Product Image">
            </div>
            <?php endif; ?>
            <div class="mh-form-wrapper">
                <form id="mh-wc-form-<?php echo $form_id; ?>" class="mh-wc-payment-form" data-form-id="<?php echo $form_id; ?>">
                    <?php foreach ( $fields as $field ) : ?>
                        <?php if ( $field['type'] === 'hidden' ) : ?>
                            <input type="hidden" name="<?php echo esc_attr( $field['label'] ); ?>" value="<?php echo esc_attr( $field['default_value'] ?? '' ); ?>">
                        <?php elseif ( $field['type'] === 'fixed_amount' ) : ?>
                            <div class="mh-form-field">
                                <label><?php echo esc_html( $field['label'] ); ?></label>
                                <input type="text" value="<?php echo esc_attr( $field['default_value'] ?? '0' ); ?>" readonly>
                                <input type="hidden" name="<?php echo esc_attr( $field['label'] ); ?>" value="<?php echo esc_attr( $field['default_value'] ?? '' ); ?>">
                            </div>
                        <?php else: ?>
                            <div class="mh-form-field">
                                <label><?php echo esc_html( $field['label'] ); ?><?php if ( !empty($field['required']) ) echo ' <span style="color:red;">*</span>'; ?></label>
                                <?php if ( $field['type'] === 'textarea' ) : ?>
                                    <textarea name="<?php echo esc_attr( $field['label'] ); ?>" <?php if ( !empty($field['required']) ) echo 'required'; ?>></textarea>
                                <?php else : ?>
                                    <input type="<?php echo esc_attr( $field['type'] ); ?>" name="<?php echo esc_attr( $field['label'] ); ?>" <?php if ( !empty($field['required']) ) echo 'required'; ?>>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <button type="submit" class="mh-form-submit-btn">המשך לתשלום</button>
                    <div class="mh-form-response"></div>
                </form>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function handle_form_submission() {
        check_ajax_referer( 'mh_wc_form_submit_nonce', 'nonce' );
        $form_id = intval( $_POST['form_id'] ?? 0 );
        $form_data = $_POST['form_data'] ?? [];
        if ( ! $form_id || empty( $form_data ) ) wp_send_json_error( [ 'message' => 'Invalid data.' ] );
        
        if ( get_post_meta( $form_id, '_mh_save_to_crm', true ) === '1' && class_exists('MH_Database_Manager') ) {
            $this->save_to_crm($form_id, $form_data, 'ממתין לתשלום');
        }

        $order_response = $this->create_programmatic_order($form_id, $form_data);
        if ( !$order_response['success'] ) {
            wp_send_json_error( [ 'message' => $order_response['message'] ] );
        }
        
        $pending_message = get_post_meta( $form_id, '_mh_wc_pending_message', true );
        $pending_image_id = get_post_meta( $form_id, '_mh_wc_pending_image_id', true );
        if ( !empty($pending_message) || !empty($pending_image_id) ) {
            $final_message = $this->build_final_message($pending_message, $form_data);
            $phone_number = $this->get_phone_from_form_data($form_id, $form_data);
            $this->send_whatsapp_message( $phone_number, $final_message, $pending_image_id );
        }
        
        wp_send_json_success( [ 'payment_url' => $order_response['payment_url'] ] );
    }

    private function create_programmatic_order($form_id, $form_data) {
        $fields_map = get_post_meta( $form_id, '_mh_form_fields', true );
        $product_name = get_post_meta( $form_id, '_mh_wc_product_name', true ) ?: 'Payment Form ' . $form_id;
        $amount = 0;
        $billing_details = [];
        $submitted_data = [];
        foreach($form_data as $field) {
            $submitted_data[$field['name']] = $field['value'];
        }
        foreach ( $fields_map as $field ) {
            $label = $field['label'];
            if (isset($submitted_data[$label])) {
                $value = $submitted_data[$label];
                if (($field['map_to'] ?? '') === 'payment_amount') {
                    $amount = floatval($value);
                }
                if ($field['type'] === 'tel') $billing_details['phone'] = $value;
                if ($field['type'] === 'email') $billing_details['email'] = $value;
                if (($field['map_to'] ?? '') === 'conta_name') {
                    $name_parts = explode(' ', $value, 2);
                    $billing_details['first_name'] = $name_parts[0];
                    $billing_details['last_name'] = $name_parts[1] ?? '';
                }
            }
        }
        if ( $amount <= 0 ) {
            return ['success' => false, 'message' => 'Invalid payment amount. Please ensure an amount field is correctly mapped and filled.'];
        }
        try {
            $order = wc_create_order();
            $order->set_address($billing_details, 'billing');
            
            $product = new WC_Product_Simple();
            $product->set_name( $product_name );
            $product->set_regular_price( $amount );
            $product->set_virtual( true );
            $product->set_catalog_visibility( 'hidden' );
            $product->set_status( 'publish' );
            $product_id = $product->save();
            if(!$product_id) throw new Exception("Could not save product.");
            
            $item_id = $order->add_product( wc_get_product($product_id), 1 );
            
            // Add meta to the order ITEM, not the order itself.
            wc_add_order_item_meta($item_id, '_mh_form_id', $form_id);
            wc_add_order_item_meta($item_id, '_mh_form_data', $form_data);

            $order->calculate_totals();
            $order->update_status('pending', 'Order created from payment form.');
            $order->save();
            return ['success' => true, 'payment_url' => $order->get_checkout_payment_url()];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Error creating order: ' . $e->getMessage()];
        }
    }

    private function save_to_crm($form_id, $form_data, $initial_status = null) {
        $original_user_id = get_current_user_id();
        $crm_owner_id = get_post_meta( $form_id, '_mh_crm_owner_id', true ) ?: 1;
        wp_set_current_user( $crm_owner_id );

        $fields_map = get_post_meta( $form_id, '_mh_form_fields', true );
        $contact_data = [];
        $label_to_db_field_map = [];
        if (is_array($fields_map)) {
            foreach ($fields_map as $mapping) {
                if (!empty($mapping['map_to']) && $mapping['map_to'] !== 'payment_amount') {
                    $label_to_db_field_map[$mapping['label']] = $mapping['map_to'];
                }
            }
        }
        $submitted_data = [];
        foreach($form_data as $field) {
            $submitted_data[$field['name']] = $field['value'];
        }
        foreach ($label_to_db_field_map as $label => $db_field) {
            if (isset($submitted_data[$label])) {
                $contact_data[$db_field] = sanitize_text_field($submitted_data[$label]);
            }
        }
        
        if ( ! empty( $contact_data['conta_phone'] ) && class_exists('MH_Database_Manager') ) {
            $db_manager = new MH_Database_Manager();
            global $wpdb;
            $table_name = $wpdb->prefix . 'mh_contacts';
            $phone = $contact_data['conta_phone'];
            $owner_id = get_current_user_id();
            $existing_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table_name} WHERE conta_phone = %s AND owner_id = %d", $phone, $owner_id));

            if ($existing_id) {
                $update_payload = [];
                if ($initial_status) {
                    $update_payload['tg1'] = $initial_status;
                }
                foreach($contact_data as $key => $value) {
                    if (!empty($value) && $key !== 'conta_phone' && $key !== 'tg1') {
                        $update_payload[$key] = $value;
                    }
                }
                if (!empty($update_payload)) {
                    $db_manager->update_contact($existing_id, $update_payload);
                }
            } else {
                if ($initial_status) {
                    $contact_data['tg1'] = $initial_status;
                }
                $db_manager->upsert_contact( $contact_data );
            }
        }
        
        wp_set_current_user( $original_user_id );
    }
    
    public function handle_payment_status_change( $order_id, $old_status, $new_status, $order ) {
        $form_id = 0;
        $form_data = [];

        foreach ( $order->get_items() as $item ) {
            $form_id = $item->get_meta( '_mh_form_id' );
            if ( $form_id ) {
                $form_data = $item->get_meta( '_mh_form_data' );
                break; 
            }
        }
        if ( !$form_id ) return;
        
        $message_template = '';
        $image_id = null;

        if ( in_array($new_status, ['completed', 'processing']) ) {
            $message_template = get_post_meta( $form_id, '_mh_wc_success_message', true );
            $image_id = get_post_meta( $form_id, '_mh_wc_success_image_id', true );
            $this->update_crm_status_on_completion($form_id, $form_data);
        } elseif ( in_array($new_status, ['failed', 'cancelled']) ) {
            $message_template = get_post_meta( $form_id, '_mh_wc_failed_message', true );
            $image_id = get_post_meta( $form_id, '_mh_wc_failed_image_id', true );
        }

        if ( empty($message_template) && empty($image_id) ) return;
        
        $final_message = $this->build_final_message($message_template, $form_data, $order);
        $phone_number = $order->get_billing_phone();
        $this->send_whatsapp_message( $phone_number, $final_message, $image_id );
    }

    private function update_crm_status_on_completion($form_id, $form_data) {
        if ( get_post_meta( $form_id, '_mh_save_to_crm', true ) !== '1' || !class_exists('MH_Database_Manager') ) {
            return;
        }
        $phone_number = $this->get_phone_from_form_data($form_id, $form_data);
        if (empty($phone_number)) return;

        $original_user_id = get_current_user_id();
        $crm_owner_id = get_post_meta( $form_id, '_mh_crm_owner_id', true ) ?: 1;
        wp_set_current_user( $crm_owner_id );
        
        $db_manager = new MH_Database_Manager();
        global $wpdb;
        $table_name = $wpdb->prefix . 'mh_contacts';
        $owner_id = get_current_user_id();
        $existing_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table_name} WHERE conta_phone = %s AND owner_id = %d", $phone_number, $owner_id));
        
        if ($existing_id) {
            $db_manager->update_contact($existing_id, ['tg1' => 'תשלום בוצע']);
        }

        wp_set_current_user($original_user_id);
    }
    
    private function get_phone_from_form_data($form_id, $form_data) {
        $fields = get_post_meta( $form_id, '_mh_form_fields', true );
        $phone_field_label = '';
        if (is_array($fields)) {
            foreach($fields as $field) {
                if ($field['type'] === 'tel') {
                    $phone_field_label = $field['label'];
                    break;
                }
            }
        }
        if (empty($phone_field_label)) return '';
        foreach($form_data as $item) {
            if ($item['name'] === $phone_field_label) return $item['value'];
        }
        return '';
    }
    
    private function build_final_message($template, $form_data, $order = null) {
        $final_message = $template;
        if(is_array($form_data)) {
            foreach ( $form_data as $field_data ) {
                $final_message = str_replace( '{' . $field_data['name'] . '}', $field_data['value'], $final_message );
            }
        }
        if ($order) {
            $final_message = str_replace('{link_kabala}', $order->get_view_order_url(), $final_message);
        }
        return $final_message;
    }

    private function send_whatsapp_message( $phone_number, $message, $attachment_id = null ) {
        if ( empty( $phone_number ) || (empty( $message ) && empty($attachment_id)) ) return;
        $id_instance = get_option( 'crm_green_id_instance' );
        $api_token   = get_option( 'crm_green_api_token' );
        if ( ! $id_instance || ! $api_token ) return;
        $clean_phone = preg_replace( '/\D/', '', $phone_number );
        if ( substr( $clean_phone, 0, 1 ) === '0' ) $clean_phone = '972' . substr( $clean_phone, 1 );
        $chat_id = $clean_phone . '@c.us';
        
        if ($attachment_id) {
            $file_url = wp_get_attachment_url($attachment_id);
            if ($file_url) {
                $url = "https://api.green-api.com/waInstance{$id_instance}/sendFileByUrl/{$api_token}";
                $body = [ 'chatId' => $chat_id, 'urlFile' => $file_url, 'fileName' => basename($file_url), 'caption' => $message ];
            }
        } else {
            $url = "https://api.green-api.com/waInstance{$id_instance}/sendMessage/{$api_token}";
            $body = [ 'chatId' => $chat_id, 'message' => $message ];
        }

        if (isset($url)) {
            wp_remote_post( $url, ['headers' => ['Content-Type' => 'application/json'], 'body' => json_encode( $body ), 'timeout' => 20] );
        }
    }
}