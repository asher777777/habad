jQuery(document).ready(function($) {
    $(document).on('submit', '.mh-wc-payment-form', function(e) {
        e.preventDefault();

        const form = $(this);
        const formWrapper = form.closest('.mh-form-wrapper');
        const formId = form.data('form-id');
        const submitBtn = form.find('.mh-form-submit-btn');
        const responseDiv = form.find('.mh-form-response');
        const formData = form.serializeArray();

        let isValid = true;
        form.find('[required]').each(function() {
            if (!$(this).val()) {
                $(this).css('border-color', 'red');
                isValid = false;
            } else {
                $(this).css('border-color', '#ccc');
            }
        });

        if (!isValid) {
            responseDiv.text('אנא מלא את כל שדות החובה.').removeClass('success').addClass('error').show();
            return;
        }

        $.ajax({
            url: mhWcFormData.ajax_url,
            type: 'POST',
            data: {
                action: 'mh_handle_wc_form',
                nonce: mhWcFormData.nonce,
                form_id: formId,
                form_data: formData
            },
            beforeSend: function() {
                submitBtn.prop('disabled', true).text('יוצר הזמנה...');
                responseDiv.hide();
            },
            success: function(response) {
                if (response.success && response.data.payment_url) {
                    // Redirect to the payment URL instead of using an iframe
                    window.location.href = response.data.payment_url;
                } else {
                    const errorMessage = response.data.message || 'אירעה שגיאה לא ידועה.';
                    responseDiv.text(errorMessage).removeClass('success').addClass('error').show();
                    submitBtn.prop('disabled', false).text('המשך לתשלום');
                }
            },
            error: function(xhr) {
                console.error('AJAX Error:', xhr);
                responseDiv.text('אירעה שגיאת תקשורת. אנא נסה שוב.').removeClass('success').addClass('error').show();
                submitBtn.prop('disabled', false).text('המשך לתשלום');
            }
        });
    });
});